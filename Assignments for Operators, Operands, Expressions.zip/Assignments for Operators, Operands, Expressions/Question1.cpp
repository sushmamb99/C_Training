// CBasics.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include<stdio.h>
int main()
{
    printf("hello world\n");
    printf("hello world\t");
    printf("hello world\r");
    printf("hello world\b");
    printf("hello world\");
  
   return 0;

}

