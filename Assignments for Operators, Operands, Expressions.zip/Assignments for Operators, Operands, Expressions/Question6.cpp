#include <iostream>

using namespace std;

int main()
{

    char ch;
    cout << "Enter the character (it maybe a alphabet or digit or any other character): " << endl;
    cin >> ch;
    cout << "The ASCCI value of " << ch << " is : " << (int)ch << endl;
}