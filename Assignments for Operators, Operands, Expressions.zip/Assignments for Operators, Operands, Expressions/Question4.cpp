//#include <iostream>
//#include <stdio.h>
//#include <math.h>
//using namespace std;
//
//int main()
//{
//
//    int num1, num2;
//    int sum;
//    cout << "Enter the 2 numbers for addition:" << endl;
//    cin >> num1 >> num2;
//    sum = num1 + num2;
//    cout << sum << endl;
//    cout <<"Sum is: "<< num1 + num2;
//}