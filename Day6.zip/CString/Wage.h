#pragma once
#include "Employee.h"

class WageEmployee : public Employee
{
	float hrs, rate;
public:
	WageEmployee();
	WageEmployee(int, const char*, int, int, int,float , float);
	void accept();//function overrriding
	void show();
	float computesal();

};
