//#include <iostream>
//#include "CString.h"
//#include "Smart.h"
//#include "date.h"
//#include "Wage.h"
//using namespace std;
//
//int main()
//{
//	{
//		/*WageEmployee we1;
//		we1.accept();
//		we1.show();
//
//		WageEmployee we1(1000,"srinath",12,2,2020,8,2000);
//		we1.accept();
//		we1.show();*/
//
//		//CString s2("mohith");
//		//CString sss(s2);
//		//CString s3 = s2+sss;
//		//CString s4 = s3 , s1;
//		///*s2.show_string();*/
//
//		//CString s3("shivu"); 
//		//s3.show_string();
//
//		//SmartPointer sptr;
//		//sptr->accept_string();
//		//(*sptr).show_string();
//
//		////s1 = s2;
//		//CString s4 = s2 + s3;
//		//s4.show_string();
//		//{
//		//	SmartPointer sptr(10, 2);
//		//	sptr->accept_string();   //overloading ->
//		//	(*sptr).show_string();   //overloading *
//		//}
//
//
//		/*CString s2('W',10);
//		s2.show_string();
//
//		CString ss(s2);
//		ss.show_string();*/
//		
//	}
//	Date d;
//	d.accept_date();
//	d.show_date();
//		
//	
//	
//
//	cout <<"Leak " << _CrtDumpMemoryLeaks() << endl;
//	return 0;
//}