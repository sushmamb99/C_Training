#pragma once

class demo1
{
	int a;
public:
	demo1();
	demo1(int);
	void show();
	int geta() { return a; }
        demo1(const demo2 d);
	void operator=(const demo1&);
};
