#pragma once
class demo1;
class demo2
{
	int b;
public:
	demo2();
	demo2(int);
	void show();
	int getb() 
	   { 
	     return b; 
	   }
	void operator=(const demo2);
	demo2 operator demo1();
};
