
#include <iostream>
#include "Mystack.h"

using namespace std;

template<typename T>
Mystack<T>::Mystack()
{
	top = -1;
	size = 5;
	m_buff = new T[size];
}
template<typename T>
void Mystack<T>::push(T x)
{
	if (top == size-1)
		cout << "Overflow" << endl;
	
	m_buff[++top] = x;

}
template<typename T>
T Mystack<T>::pop()
{
	if (top == -1)
		cout << "Underflow" << endl;

	return m_buff[top--];
}
template<typename T>
void Mystack<T>::display()
{
	if (top ==-1)
		cout << "Underflow" << endl;

	for (int i = top;i >=0;i--)
		cout << m_buff[i] << endl;

}
template<typename T>
Mystack<T>::~Mystack()
{
	if(m_buff)
		delete m_buff;
	m_buff = nullptr;
}
