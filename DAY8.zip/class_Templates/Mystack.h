#pragma once
template<typename T>

class Mystack
{
	int top;
	int size;
	T* m_buff;
public:
	Mystack();
	void push(T);
	T pop();
	void display();
	~Mystack();
};