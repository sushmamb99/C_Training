// stl.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <vector>
#include <list>
#include <map>

using namespace std;
class Employee
{
    int empid;
    string name;
public:
    Employee(){}
    Employee(int id , string nm):empid(id),name(nm){}
    void accept()
    {
        cout << "Enter empid and name" << endl;
        cin >> empid >> name;
    }
    void show()const
    {
        cout << empid << " " << name << endl;
    }
    bool operator < (const Employee& e)const
    {
        return name < e.name;
    }

    bool operator == (const Employee& e)//this has to be const
    {
        return name == e.name;
    }
};
int main()
{
   // vector<int> v1{ 1,2,3,4,5 };
   //cout << v1.size()<<endl;
   // cout << v1.capacity() << endl;
   // v1.push_back(100);
   // v1.push_back(200);
   // v1.push_back(300);

   // for (int i = 0;i < v1.size();i++)
   //     cout << v1[i] << " " << v1.at(i) << endl;

   // cout << "Using iterator " << endl;
   // for (vector<int>::iterator itr = v1.begin();itr != v1.end();++itr)
   //     cout << *itr << endl;
   // //vector<const int> v2{ 1,2,3,4,5 };
   //
   // cout << "Using iterator " << endl;
   // for (vector<int>::reverse_iterator itr = v1.rbegin();itr != v1.rend();++itr)
   //     cout << *itr << endl;
   //// for_each(v1.begin(), v1.end(), show);
   // v1.pop_back();
   // v1.insert(v1.begin(), 99);
   //v1.erase(v1.begin(), v1.end() - 2);
   /* for (auto i : v1)
        cout << i << endl;*/
    //vector<Employee> v1(7);
    //v1[0] = Employee(100, "Amith");
    //v1[1] = Employee(200, "Shard");
    //v1[2] = Employee(300, "Ramu");
    //v1.push_back(Employee(400, "Tamnna"));

    ////vector<int> v3{ 1,2,3,4,5 };
    //auto itr = find(v1.begin(), v1.end(), Employee(300,"Ramu"));
    //if (itr != v1.end())
    //    cout << "Element is present" << endl;
    //else
    //    cout << "Element is not present" << endl;
   /* cout << "Employee Records" << endl;
    for (vector<Employee>::iterator itr = v1.begin();itr != v1.end();++itr)
        itr->accept();
    for (vector<Employee>::iterator itr = v1.begin();itr != v1.end();++itr)
        itr->show();
    cout << v1.capacity();*/
   //
    //std::sort(v1.begin(), v1.end());
   /* vector<int> v3{1,2,3,4,5};
    auto itr = find(v3.begin(), v3.end(), 5);
    if (itr != v3.end())
        cout << "Element is present" << endl;
    else
        cout << "Element is not present" << endl;*/

    //list<int> l;
    //for (int i = 1;i < 10;i++)
    //    l.push_back(i * 10);
    //for (auto i : l)
    //    cout << i << endl;

   /* set<Employee> s;
    s.insert(Employee(100, "kirak"));
    s.insert(Employee(200, "kirk"));
    s.insert(Employee(300, "kk"));
    s.insert(Employee(400, "kiak"));
    for (set<Employee>::iterator itr = s.begin();itr != s.end();++itr)
        itr->show();*/

    map<string, int> mymap;
    mymap.insert(pair<string, int>("shvang", 10));
    mymap.insert(pair<string, int>("shvang", 20));
    mymap.insert(pair<string, int>("shvanjbxqsg", 10));
    mymap.insert(pair<string, int>("shvangjwkbxicuw", 30));

    for (map<string, int>::iterator itr = mymap.begin();itr != mymap.end();++itr)
        cout << itr->first() << " " << itr->second() << endl;
    return 0;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
